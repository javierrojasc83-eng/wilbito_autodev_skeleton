from typing import Any, Dict, List
from wilbito.memory.context import retrieve_context

def run(objetivo: str, max_iter: int = 2, granularity: str = "coarse", use_context: bool = False, top_k: int = 5):
    """
    Council Agent: simula debate multi-agente con opcional contexto RAG.
    """
    context = retrieve_context(objetivo, top_k=top_k) if use_context else []

    tasks = ["investigar", "prototipar", "evaluar", "documentar"] if granularity != "fine" \
            else ["investigar", "prototipar", "tests", "evaluar", "documentar", "retroalimentar"]

    iteraciones: List[Dict[str, Any]] = []
    for i in range(max_iter):
        iteraciones.append({
            "iter": i + 1,
            "artefacto": {
                "artefacto": "demo.py",
                "contenido": f"# Auto-generado iter {i+1} para: {objetivo}\n"
                             f"def demo():\n"
                             f"    return 'ok'\n"
            },
            "eval": {"passed": True, "metrics": {"tests": "ok"}}
        })

    return {
        "rfc": {
            "title": f"RFC: {objetivo}",
            "summary": f"Plan de alto nivel para cumplir el objetivo {objetivo}.",
            "tasks": tasks,
            "risks": ["tiempo", "complejidad", "dependencias"]
        },
        "research": {
            "topic": objetivo,
            "findings": [
                f"Hipótesis inicial sobre {objetivo}",
                "Patrón Strategy para agentes",
                "Circuit-breaker para herramientas externas"
            ]
        },
        "contexto": context,   # lista de hits del vectorstore
        "iteraciones": iteraciones
    }
