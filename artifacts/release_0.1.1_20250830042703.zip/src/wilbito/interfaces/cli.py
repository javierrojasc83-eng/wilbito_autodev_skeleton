import typer
import json
from wilbito.agents import router, council
from wilbito.tools import trading, quality as quality_tools, release as release_tools, pr as pr_tools
from wilbito.memory import diario as diario_tools

app = typer.Typer(help="CLI Wilbito Autodev")

@app.command()
def plan(objetivo: str):
    """
    Planificar objetivo y mostrar tareas.
    """
    tasks = [
        {"id": 1, "tipo": "investigar", "payload": {"objetivo": objetivo}},
        {"id": 2, "tipo": "prototipar", "payload": {"objetivo": objetivo}},
        {"id": 3, "tipo": "evaluar", "payload": {"objetivo": objetivo}},
        {"id": 4, "tipo": "documentar", "payload": {"objetivo": objetivo}},
    ]
    typer.echo(json.dumps(tasks, indent=4, ensure_ascii=False))


@app.command()
def autodev(objetivo: str, max_iter: int = 1):
    """
    Ejecuta el ciclo de autodesarrollo mínimo.
    """
    result = router.run(objetivo=objetivo, max_iter=max_iter)
    typer.echo(json.dumps(result, indent=4, ensure_ascii=False))


@app.command()
def council(objetivo: str, max_iter: int = 2, granularity: str = "coarse"):
    """
    Ejecuta el consejo multi-agente.
    """
    result = council.run(objetivo=objetivo, max_iter=max_iter, granularity=granularity)
    typer.echo(json.dumps(result, indent=4, ensure_ascii=False))


@app.command("trading-backtest")
def trading_backtest(par: str, n: int = 100):
    """
    Backtest simulado (placeholder).
    """
    result = trading.backtest(par=par, n=n)
    typer.echo(json.dumps(result, indent=4, ensure_ascii=False))


@app.command()
def diario(texto: str):
    """
    Escribe una entrada en el diario.
    """
    result = diario_tools.write_entry(texto)
    typer.echo(json.dumps(result, indent=4, ensure_ascii=False))


@app.command()
def quality():
    """
    Corre pruebas de calidad (lint sintáctico + tests mínimos).
    """
    result = quality_tools.run_quality()
    typer.echo(json.dumps(result, indent=4, ensure_ascii=False))


@app.command()
def pr(objetivo: str):
    """
    Ejecuta revisión de PR simulada.
    """
    result = pr_tools.run_pr_review(objetivo=objetivo)
    typer.echo(json.dumps(result, indent=4, ensure_ascii=False))


@app.command()
def release(bump: str = "patch"):
    """
    Genera un release y actualiza CHANGELOG.md
    """
    result = release_tools.run_release(bump=bump)
    typer.echo(json.dumps(result, indent=4, ensure_ascii=False))


if __name__ == "__main__":
    app()
