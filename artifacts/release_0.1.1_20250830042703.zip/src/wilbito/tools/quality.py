import glob, os

def _check_file_syntax(fp: str):
    try:
        with open(fp, "r", encoding="utf-8") as f:
            code = f.read()
        compile(code, fp, "exec")
        return {"syntax_ok": True, "errors": []}
    except SyntaxError as e:
        return {"syntax_ok": False, "errors": [f"{e.msg} at line {e.lineno}: {e.text}"]}

def run_quality():
    """
    Lint sintáctico sobre artifacts/codegen/*.py (sin pytest).
    """
    files = glob.glob(os.path.join("artifacts", "codegen", "*.py"))
    if not files:
        return {"info": "No hay artefactos aún en artifacts/codegen/."}
    results = {}
    for fp in files:
        results[fp] = _check_file_syntax(fp)
    return results
