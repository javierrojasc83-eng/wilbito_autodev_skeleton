import typer
import json

# Alias para evitar colisiones nombre-función vs. módulo
from wilbito.agents import router as router_mod, council as council_mod
from wilbito.tools import trading as trading_mod, quality as quality_mod, release as release_mod, pr as pr_mod
from wilbito.memory import diario as diario_mod

app = typer.Typer(help="CLI Wilbito Autodev")

# -------------------------------------------------------------------
# PLAN
# -------------------------------------------------------------------
@app.command()
def plan(objetivo: str):
    """
    Planificar objetivo y mostrar tareas.
    """
    steps = ["investigar", "prototipar", "evaluar", "documentar"]
    plan = [
        {"id": i + 1, "tipo": step, "payload": {"objetivo": objetivo}}
        for i, step in enumerate(steps)
    ]
    typer.echo(json.dumps(plan, indent=4, ensure_ascii=False))


# -------------------------------------------------------------------
# AUTODEV
# -------------------------------------------------------------------
@app.command()
def autodev(objetivo: str, max_iter: int = 1):
    """
    Ejecuta el ciclo de autodesarrollo mínimo.
    """
    result = router_mod.run(objetivo=objetivo, max_iter=max_iter)
    typer.echo(json.dumps(result, indent=4, ensure_ascii=False))


# -------------------------------------------------------------------
# COUNCIL
# -------------------------------------------------------------------
@app.command("council")
def council_cmd(objetivo: str, max_iter: int = 2, granularity: str = "coarse"):
    """
    Ejecuta el consejo multi-agente.
    """
    result = council_mod.run(
        objetivo=objetivo, max_iter=max_iter, granularity=granularity
    )
    typer.echo(json.dumps(result, indent=4, ensure_ascii=False))


# -------------------------------------------------------------------
# TRADING
# -------------------------------------------------------------------
@app.command("trading-backtest")
def trading_backtest(par: str, n: int = 100):
    """
    Backtest simulado (placeholder).
    """
    result = trading_mod.backtest(par=par, n=n)
    typer.echo(json.dumps(result, indent=4, ensure_ascii=False))


# -------------------------------------------------------------------
# DIARIO
# -------------------------------------------------------------------
@app.command()
def diario(texto: str):
    """
    Escribe una entrada en el diario.
    """
    result = diario_mod.write_entry(texto)
    typer.echo(json.dumps(result, indent=4, ensure_ascii=False))


# -------------------------------------------------------------------
# QUALITY
# -------------------------------------------------------------------
@app.command()
def quality():
    """
    Corre pruebas de calidad (lint sintáctico + tests si existen).
    """
    result = quality_mod.run_quality()
    typer.echo(json.dumps(result, indent=4, ensure_ascii=False))


# -------------------------------------------------------------------
# PR REVIEW
# -------------------------------------------------------------------
@app.command("pr")
def pr_review(objetivo: str):
    """
    Ejecuta revisión de PR simulada.
    """
    result = pr_mod.run_pr_review(objetivo)
    typer.echo(json.dumps(result, indent=4, ensure_ascii=False))


# -------------------------------------------------------------------
# RELEASE
# -------------------------------------------------------------------
@app.command("release")
def release_cmd(bump: str = "patch"):
    """
    Genera un release y actualiza CHANGELOG.md.
    """
    result = release_mod.run_release(bump=bump)
    typer.echo(json.dumps(result, indent=4, ensure_ascii=False))


if __name__ == "__main__":
    app()
