import os, datetime

def _diary_path():
    today = datetime.datetime.now()
    base = os.path.join("memoria", "diario_wilbito", f"{today:%Y}", f"{today:%m}")
    os.makedirs(base, exist_ok=True)
    return os.path.join(base, f"diario_{today:%Y%m%d}.md")

def write_entry(texto: str):
    fp = _diary_path()
    with open(fp, "a", encoding="utf-8") as f:
        f.write(f"\n[{datetime.datetime.now().isoformat()}] {texto}\n")
    return {"ok": True, "file": fp}
