import os, datetime
from wilbito.memory.vectorstore import VectorStore

def _diary_path():
    today = datetime.datetime.now()
    base = os.path.join("memoria", "diario_wilbito", f"{today:%Y}", f"{today:%m}")
    os.makedirs(base, exist_ok=True)
    return os.path.join(base, f"diario_{today:%Y%m%d}.md")

def write_entry(texto: str, tag: str = "diario"):
    fp = _diary_path()
    ts = datetime.datetime.now().isoformat()
    line = f"\n[{ts}] {texto}\n"
    with open(fp, "a", encoding="utf-8") as f:
        f.write(line)

    # Auto-ingesta a memoria vectorial
    vs = VectorStore()
    vs.add_texts([{"text": texto, "meta": {"tag": tag, "source": "diario", "timestamp": ts, "file": fp}}])

    return {"ok": True, "file": fp, "ingested": True, "tag": tag}
