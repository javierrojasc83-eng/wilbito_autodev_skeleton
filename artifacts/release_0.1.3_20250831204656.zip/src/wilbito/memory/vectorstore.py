# src/wilbito/memory/vectorstore.py
# VectorStore minimalista, sin numpy. Embeddings deterministas + cosine
# + limpieza de acentos/stopwords + boost por tag detectado en el query.

from __future__ import annotations
import json
import os
import math
import hashlib
import uuid
import re
import unicodedata
from typing import List, Dict, Any, Optional

DIM = 256  # dimensión del "embedding" tipo bag-of-hashed-words

# Stopwords cortas (es/en) para bajar ruido
STOPWORDS = {
    # español
    "a","acá","al","algo","algún","alguna","algunas","alguno","algunos","ante","antes","aquel","aquella",
    "aquellas","aquello","aquellos","aqui","aquí","así","aun","aún","aunque","bajo","bien","cada","como","cómo",
    "con","contra","cual","cuales","cuál","cuáles","cuando","cuándo","de","del","desde","donde","dónde","dos",
    "el","él","ella","ellas","ello","ellos","en","entre","era","eramos","éramos","eran","es","esa","esas",
    "ese","eso","esos","esta","está","están","estaba","estaban","estamos","estar","este","esto","estos",
    "fue","fueron","ha","han","hasta","hay","la","las","le","les","lo","los","más","mas","me","mi","mis",
    "mucha","muchas","mucho","muchos","muy","nada","ni","no","nos","nosotros","nuestra","nuestras","nuestro",
    "nuestros","o","os","otra","otras","otro","otros","para","pero","poco","por","porque","que","qué","quien",
    "quién","quienes","se","segun","según","ser","si","sí","sin","sobre","su","sus","te","ti","tiene","tienen",
    "tu","tus","un","una","uno","unos","usted","ustedes","y","ya",
    # inglés
    "a","an","the","and","or","but","if","then","else","when","where","who","what","why","how","is","are",
    "was","were","be","been","being","of","to","in","on","for","from","by","with","about","as","at","into",
    "over","after","before","under","again","further","more","most","some","such","no","nor","not","only",
    "own","same","so","than","too","very","can","will","just","don","should","now"
}

TAG_VOCAB = {"codegen", "marketing", "trading"}  # para boost por tag en query


def _normalize(text: str) -> str:
    # bajar a minúsculas + quitar acentos
    text = text.lower()
    text = unicodedata.normalize("NFKD", text)
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    return text


def _tokenize(text: str) -> List[str]:
    text = _normalize(text)
    # palabras alfanuméricas (incluye guiones como separadores)
    toks = re.findall(r"[a-z0-9]+", text)
    return [t for t in toks if t and t not in STOPWORDS]


def _hash_token(token: str, dim: int = DIM) -> int:
    h = hashlib.md5(token.encode("utf-8")).hexdigest()
    return int(h, 16) % dim


def _embed(text: str, dim: int = DIM) -> List[float]:
    vec = [0.0] * dim
    toks = _tokenize(text)
    for tok in toks:
        idx = _hash_token(tok, dim)
        vec[idx] += 1.0
    # L2
    norm = math.sqrt(sum(v * v for v in vec)) or 1.0
    return [v / norm for v in vec]


def _cosine(a: List[float], b: List[float]) -> float:
    dot = 0.0
    na = 0.0
    nb = 0.0
    L = min(len(a), len(b))
    for i in range(L):
        ai = a[i]; bi = b[i]
        dot += ai * bi
        na += ai * ai
        nb += bi * bi
    if na == 0 or nb == 0:  # evita división por cero
        return 0.0
    return dot / (math.sqrt(na) * math.sqrt(nb))


def _tags_in_query(query: str) -> List[str]:
    # Detecta tags conocidas en el query (codegen/marketing/trading)
    toks = set(_tokenize(query))
    return [t for t in TAG_VOCAB if t in toks]


class VectorStore:
    """
    Formato en disco (JSON):
    {
      "items": [
        {"id": "...", "text": "....", "meta": {...}, "vector": [floats]}
      ]
    }
    """

    def __init__(self, items: Optional[List[Dict[str, Any]]] = None):
        self.items: List[Dict[str, Any]] = items or []
        self._texts = {it["text"] for it in self.items if "text" in it}

    # ----------------------
    # Persistencia
    # ----------------------
    def save(self, path: str) -> None:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump({"items": self.items}, f, ensure_ascii=False)

    @classmethod
    def load(cls, path: str) -> "VectorStore":
        if not os.path.exists(path):
            return cls(items=[])
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        items: List[Dict[str, Any]] = []
        if isinstance(data, dict) and "items" in data:
            items = data["items"] or []
        elif isinstance(data, dict) and "texts" in data and "vectors" in data:
            # compat formatos viejos
            texts = data.get("texts") or []
            vecs = data.get("vectors") or []
            metas = data.get("meta") or []
            for i, text in enumerate(texts):
                items.append({
                    "id": str(uuid.uuid4()),
                    "text": text,
                    "meta": metas[i] if i < len(metas) else {},
                    "vector": vecs[i] if i < len(vecs) else _embed(text),
                })

        # asegura vector embebido
        for it in items:
            if "vector" not in it or not isinstance(it["vector"], list):
                it["vector"] = _embed(it.get("text", ""))

        return cls(items=items)

    # ----------------------
    # Mutaciones
    # ----------------------
    def add_text(self, text: str, meta: Optional[Dict[str, Any]] = None) -> bool:
        if not text or text in self._texts:
            return False
        vec = _embed(text)
        item = {
            "id": str(uuid.uuid4()),
            "text": text,
            "meta": meta or {},
            "vector": vec,
        }
        self.items.append(item)
        self._texts.add(text)
        return True

    # ----------------------
    # Búsqueda
    # ----------------------
    def search(
        self,
        query: str,
        top_k: int = 5,
        min_score: float = 0.0,
        prefer_tags: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        if not self.items or not query:
            return []
        q = _embed(query)

        # Detecta tags en query si no las pasan explícitas
        if prefer_tags is None:
            prefer_tags = _tags_in_query(query)
        prefer_tags = set(prefer_tags or [])

        scored = []
        for it in self.items:
            s = _cosine(q, it["vector"])
            # boost si el meta.tag está en prefer_tags
            tag = (it.get("meta") or {}).get("tag")
            if tag and tag in prefer_tags:
                s *= 1.4
            if s >= min_score:
                scored.append((s, it))

        scored.sort(key=lambda x: x[0], reverse=True)
        out = []
        for s, it in scored[: max(top_k, 1)]:
            out.append({
                "id": it["id"],
                "score": round(float(s), 4),
                "text": it["text"],
                "meta": it.get("meta", {}),
            })
        return out
