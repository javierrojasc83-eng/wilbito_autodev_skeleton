import json
import os
import shutil
from datetime import datetime
from pathlib import Path
import typer

from wilbito.memory.vectorstore import VectorStore
from wilbito.memory.diario import write_entry
from wilbito.tools.trading import backtest as trading_backtest
from wilbito.tools.quality import run_quality
from wilbito.tools.release import run_release
from wilbito.tools.pr import run_pr_review
from wilbito.agents import router, council

# Config (usa sección + clave separadas)
try:
    from wilbito.config.loader import load_config, get_default
except Exception:
    def load_config():
        return {}
    def get_default(cfg: dict, section: str, key: str, default):
        try:
            s = cfg.get(section, {})
            if isinstance(s, dict):
                return s.get(key, default)
        except Exception:
            pass
        return default

CFG = load_config()
app = typer.Typer(help="CLI Wilbito Autodev")


# -------------------------
# PLAN
# -------------------------
@app.command("plan")
def plan_cmd(objetivo: str):
    tasks = [
        {"id": 1, "tipo": "investigar", "payload": {"objetivo": objetivo}},
        {"id": 2, "tipo": "prototipar", "payload": {"objetivo": objetivo}},
        {"id": 3, "tipo": "evaluar", "payload": {"objetivo": objetivo}},
        {"id": 4, "tipo": "documentar", "payload": {"objetivo": objetivo}},
    ]
    print(json.dumps(tasks, ensure_ascii=False, indent=4))


# -------------------------
# AUTODEV (con RAG opcional)
# -------------------------
@app.command("autodev")
def autodev_cmd(
    objetivo: str,
    max_iter: int = typer.Option(
        get_default(CFG, "router", "max_iter_default", 1),
        help="Iteraciones máximas"
    ),
    use_context: bool = typer.Option(
        get_default(CFG, "router", "use_context_default", False),
        help="Activar recuperación de contexto (RAG)",
        show_default=True
    ),
    top_k: int = typer.Option(
        get_default(CFG, "router", "top_k_default", 5),
        help="Resultados de memoria"
    ),
):
    contexto = []
    if use_context:
        db_path = Path("memoria") / "vector_db" / "vectorstore.json"
        vdb = VectorStore.load(str(db_path))
        contexto = vdb.search(objetivo, top_k=top_k)

    iters = router.run(objetivo=objetivo, max_iter=max_iter)
    out = {"objetivo": objetivo}
    if use_context:
        out["contexto"] = contexto
    out["iteraciones"] = iters
    print(json.dumps(out, ensure_ascii=False, indent=4))


# -------------------------
# COUNCIL (con RAG opcional)
# -------------------------
@app.command("council")
def council_cmd(
    objetivo: str,
    max_iter: int = typer.Option(
        get_default(CFG, "council", "max_iter_default", 2),
        help="Iteraciones de consejo"
    ),
    granularity: str = typer.Option(
        get_default(CFG, "council", "granularity_default", "coarse"),
        help="coarse|fine"
    ),
    use_context: bool = typer.Option(
        get_default(CFG, "council", "use_context_default", False),
        help="Activar recuperación de contexto (RAG)",
        show_default=True
    ),
    top_k: int = typer.Option(
        get_default(CFG, "council", "top_k_default", 5),
        help="Resultados de memoria"
    ),
):
    contexto = []
    if use_context:
        db_path = Path("memoria") / "vector_db" / "vectorstore.json"
        vdb = VectorStore.load(str(db_path))
        contexto = vdb.search(objetivo, top_k=top_k)

    result = council.run(objetivo=objetivo, max_iter=max_iter, granularity=granularity)
    if use_context:
        result["contexto"] = contexto
    print(json.dumps(result, ensure_ascii=False, indent=4))


# -------------------------
# TRADING
# -------------------------
@app.command("trading-backtest")
def trading_cmd(par: str, n: int = typer.Option(100, help="Número de trades")):
    result = trading_backtest(par=par, n=n)
    print(json.dumps(result, ensure_ascii=False, indent=4))


# -------------------------
# DIARIO (auto-ingesta opcional)
# -------------------------
@app.command("diario")
def diario_cmd(texto: str, tag: str = typer.Option(None, help="Etiqueta para auto-ingestarlo a memoria")):
    info = write_entry(texto)
    if tag:
        db_path = Path("memoria") / "vector_db" / "vectorstore.json"
        vdb = VectorStore.load(str(db_path))
        vdb.add_text(texto, meta={"tag": tag, "source": "diario", "timestamp": datetime.now().isoformat()})
        vdb.save(str(db_path))
        info["ingested"] = True
        info["tag"] = tag
    print(json.dumps(info, ensure_ascii=False, indent=4))


# -------------------------
# QUALITY
# -------------------------
@app.command("quality")
def quality_cmd():
    result = run_quality()
    print(json.dumps(result, ensure_ascii=False, indent=4))


# -------------------------
# PR REVIEW
# -------------------------
@app.command("pr")
def pr_cmd(objetivo: str):
    result = run_pr_review(objetivo)
    print(json.dumps(result, ensure_ascii=False, indent=4))


# -------------------------
# RELEASE
# -------------------------
@app.command("release")
def release_cmd(bump: str = typer.Option("patch", help="major|minor|patch")):
    result = run_release(bump=bump)
    print(json.dumps(result, ensure_ascii=False, indent=4))


# -------------------------
# MEM: INGESTAR UNA NOTA
# -------------------------
@app.command("mem-ingest")
def mem_ingest_cmd(texto: str, etiqueta: str = typer.Option(None, help="Etiqueta opcional")):
    db_path = Path("memoria") / "vector_db" / "vectorstore.json"
    vdb = VectorStore.load(str(db_path))
    vdb.add_text(texto, meta={"tag": etiqueta} if etiqueta else {})
    vdb.save(str(db_path))
    print(json.dumps({"ok": True, "ingested": 1, "tag": etiqueta or None}, ensure_ascii=False, indent=4))


# -------------------------
# MEM: BUSCAR
# -------------------------
@app.command("mem-search")
def mem_search_cmd(query: str, top_k: int = typer.Option(5, help="Top K")):
    db_path = Path("memoria") / "vector_db" / "vectorstore.json"
    vdb = VectorStore.load(str(db_path))
    results = vdb.search(query, top_k=top_k)
    print(json.dumps({"query": query, "results": results}, ensure_ascii=False, indent=4))


# -------------------------
# NUEVO: MEM-BACKUP
# -------------------------
@app.command("mem-backup")
def mem_backup_cmd():
    src = Path("memoria") / "vector_db" / "vectorstore.json"
    if not src.exists():
        print(json.dumps({"ok": False, "error": f"No existe {src}"}, ensure_ascii=False, indent=4))
        raise typer.Exit(code=1)
    backup_dir = Path("memoria") / "vector_db" / "backup"
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.utcnow().strftime("%Y%m%d%H%M%S")
    dst = backup_dir / f"vectorstore_{stamp}.json"
    shutil.copyfile(src, dst)
    print(json.dumps({"ok": True, "backup": str(dst)}, ensure_ascii=False, indent=4))


# -------------------------
# NUEVO: MEM-SEED (JSONL)
# -------------------------
@app.command("mem-seed")
def mem_seed_cmd(
    seeds_path: str = typer.Option(
        "config/seeds.jsonl",
        "--seeds-path",
        "--path",  # alias pedido
        help="Ruta al JSONL de semillas"
    )
):
    sp = Path(seeds_path)
    if not sp.exists():
        print(json.dumps({"ok": False, "error": f"No existe {sp}"}, ensure_ascii=False, indent=4))
        raise typer.Exit(code=1)

    db_path = Path("memoria") / "vector_db" / "vectorstore.json"
    vdb = VectorStore.load(str(db_path))

    added = 0
    with sp.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
                text = rec.get("text")
                tag = rec.get("tag")
                if not text:
                    continue
                meta = {"tag": tag, "source": "seed"} if tag else {"source": "seed"}
                vdb.add_text(text, meta=meta)
                added += 1
            except Exception:
                continue

    vdb.save(str(db_path))
    print(json.dumps({"ok": True, "ingested": added, "db": str(db_path)}, ensure_ascii=False, indent=4))


if __name__ == "__main__":
    app()
