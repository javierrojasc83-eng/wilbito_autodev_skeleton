import glob
import os
import subprocess
import sys

def _check_file_syntax(fp: str):
    try:
        with open(fp, "r", encoding="utf-8") as f:
            code = f.read()
        compile(code, fp, "exec")
        return {"syntax_ok": True, "errors": []}
    except SyntaxError as e:
        return {"syntax_ok": False, "errors": [f"{e.msg} at line {e.lineno}: {e.text}"]}

def _run_pytest_if_present():
    tests_dir = os.path.join("tests")
    if not os.path.isdir(tests_dir):
        return {"skipped": True, "reason": "no tests/ dir"}
    try:
        # Ejecuta pytest -q
        subprocess.run([sys.executable, "-m", "pytest", "-q"], check=True)
        return {"status": "ok"}
    except FileNotFoundError:
        return {"status": "skipped", "reason": "pytest no instalado"}
    except subprocess.CalledProcessError as e:
        return {"status": "fail", "detail": str(e)}

def run_quality():
    """
    Lint sintáctico sobre artifacts/codegen/*.py + pytest si existe.
    """
    files = glob.glob(os.path.join("artifacts", "codegen", "*.py"))
    lint = {}
    if not files:
        lint = {"info": "No hay artefactos aún en artifacts/codegen/."}
    else:
        for fp in files:
            lint[fp] = _check_file_syntax(fp)

    tests = _run_pytest_if_present()
    return {"lint": lint, "tests": tests}
